---
layout: default
title: Úvodní stránka
---

# Minimum Working Example

This is a minimum working example from my [post about typesetting LaTeX with Jekyll](https://slama.dev/typesetting-math-with-latex-in-jekyll/). If everything went well, you should be seeing math.

---

Polynomials:
{% latex %} 3x^2 + 2x + 5 {% endlatex %}

Matrices:
{% latex display %}
A = 
\begin{bmatrix}
	1 & 2 & 3 \\
	1 & 2 & 3 \\
	1 & 2 & 3 \\
\end{bmatrix}
{% endlatex %}

Sums:
{% latex display %}
\sum_{i = 0}^{\infty} \binom{i}{k} \binom{j}{k} = \binom{i + j}{i}
{% endlatex %}

Systems of equations:
{% latex display %}
\begin{aligned}
a + 3b - c &= 32\\
2a - 2b - c &= -7\\
-a + b &= 5\\
\end{aligned}
{% endlatex %}
